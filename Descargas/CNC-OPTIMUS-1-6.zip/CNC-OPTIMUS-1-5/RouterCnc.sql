-- phpMyAdmin SQL Dump
-- version 3.5.8.2
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 14-07-2014 a las 02:38:32
-- Versión del servidor: 5.5.37
-- Versión de PHP: 5.5.12

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `RouterCnc`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Graficos`
--

CREATE TABLE IF NOT EXISTS `Graficos` (
  `x` int(10) DEFAULT NULL,
  `y` int(10) DEFAULT NULL,
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `fecha` datetime DEFAULT NULL,
  `usuario` varchar(20) DEFAULT NULL,
  `nombre` varchar(20) NOT NULL,
  PRIMARY KEY (`id`,`nombre`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COMMENT='latin1_swedish_ci' AUTO_INCREMENT=2533 ;

--
-- Volcado de datos para la tabla `Graficos`
--

INSERT INTO `Graficos` (`x`, `y`, `id`, `fecha`, `usuario`, `nombre`) VALUES
(567, 365, 8, '2014-02-16 00:00:00', 'Denis', 'UNO3'),
(653, 190, 9, '2014-02-16 00:00:00', 'Denis', 'UNO3'),
(476, 291, 14, '2014-02-17 00:00:00', 'Denis', 'FDG'),
(524, 390, 15, '2014-02-17 00:00:00', 'Denis', 'FDG'),
(551, 257, 16, '2014-02-17 00:00:00', 'Denis', 'FDG'),
(311, 156, 342, '2014-06-22 00:00:00', 'Denis', 'Proyecto uno'),
(224, 229, 343, '2014-06-22 00:00:00', 'Denis', 'Proyecto dos'),
(486, 231, 344, '2014-06-22 00:00:00', 'Denis', 'Proyecto dos'),
(187, 107, 2155, '2014-07-12 00:00:00', 'Denis', 'DOS'),
(332, 312, 2156, '2014-07-12 00:00:00', 'Denis', 'DOS'),
(453, 153, 2157, '2014-07-12 00:00:00', 'Denis', 'DOS'),
(276, 183, 2160, '2014-07-12 00:00:00', 'Denis', 'Proyecto tres'),
(662, 194, 2161, '2014-07-12 00:00:00', 'Denis', 'Proyecto tres'),
(0, 0, 2162, '2014-07-12 00:00:00', 'Denis', 'Proyecto tres'),
(668, 273, 2163, '2014-07-12 00:00:00', 'Denis', 'Proyecto tres'),
(262, 271, 2164, '2014-07-12 00:00:00', 'Denis', 'Proyecto tres'),
(0, 0, 2165, '2014-07-12 00:00:00', 'Denis', 'Proyecto tres'),
(419, 340, 2166, '2014-07-12 00:00:00', 'Denis', 'Proyecto tres'),
(388, 411, 2167, '2014-07-12 00:00:00', 'Denis', 'Proyecto tres'),
(434, 436, 2168, '2014-07-12 00:00:00', 'Denis', 'Proyecto tres'),
(0, 0, 2169, '2014-07-12 00:00:00', 'Denis', 'Proyecto tres'),
(296, 33, 2170, '2014-07-12 00:00:00', 'Denis', 'Proyecto tres'),
(481, 46, 2171, '2014-07-12 00:00:00', 'Denis', 'Proyecto tres'),
(454, 165, 2172, '2014-07-12 00:00:00', 'Denis', 'Proyecto tres'),
(274, 135, 2173, '2014-07-12 00:00:00', 'Denis', 'Proyecto tres'),
(293, 37, 2174, '2014-07-12 00:00:00', 'Denis', 'Proyecto tres'),
(437, 297, 2175, '2014-07-12 00:00:00', 'Denis', 'Proyecto tres'),
(278, 442, 2176, '2014-07-12 00:00:00', 'Denis', 'Proyecto tres'),
(89, 379, 2177, '2014-07-12 00:00:00', 'Denis', 'Proyecto tres'),
(92, 96, 2186, '2014-07-12 00:00:00', 'Denis', 'Proyecto triangulo'),
(161, 291, 2187, '2014-07-12 00:00:00', 'Denis', 'Proyecto triangulo'),
(380, 155, 2188, '2014-07-12 00:00:00', 'Denis', 'Proyecto triangulo'),
(294, 98, 2189, '2014-07-12 00:00:00', 'Denis', 'Proyecto triangulo'),
(54, 438, 2190, '2014-07-12 00:00:00', 'Denis', 'Proyecto triangulo'),
(222, 224, 2398, '2014-07-13 00:00:00', 'Denis', 'ESTRELLA'),
(282, 143, 2399, '2014-07-13 00:00:00', 'Denis', 'ESTRELLA'),
(364, 224, 2400, '2014-07-13 00:00:00', 'Denis', 'ESTRELLA'),
(342, 142, 2401, '2014-07-13 00:00:00', 'Denis', 'ESTRELLA'),
(422, 116, 2402, '2014-07-13 00:00:00', 'Denis', 'ESTRELLA'),
(347, 75, 2403, '2014-07-13 00:00:00', 'Denis', 'ESTRELLA'),
(312, 5, 2404, '2014-07-13 00:00:00', 'Denis', 'ESTRELLA'),
(270, 64, 2405, '2014-07-13 00:00:00', 'Denis', 'ESTRELLA'),
(189, 39, 2406, '2014-07-13 00:00:00', 'Denis', 'ESTRELLA'),
(247, 110, 2407, '2014-07-13 00:00:00', 'Denis', 'ESTRELLA'),
(222, 223, 2408, '2014-07-13 00:00:00', 'Denis', 'ESTRELLA'),
(98, 25, 2472, '2014-07-13 00:00:00', 'Denis', 'Proyecto cuatro'),
(128, 50, 2473, '2014-07-13 00:00:00', 'Denis', 'Proyecto cuatro'),
(140, 22, 2474, '2014-07-13 00:00:00', 'Denis', 'CUATRO'),
(21, 203, 2475, '2014-07-13 00:00:00', 'Denis', 'CUATRO'),
(282, 203, 2476, '2014-07-13 00:00:00', 'Denis', 'CUATRO'),
(142, 23, 2477, '2014-07-13 00:00:00', 'Denis', 'CUATRO'),
(0, 0, 2478, '2014-07-13 00:00:00', 'Denis', 'CUATRO'),
(352, 21, 2479, '2014-07-13 00:00:00', 'Denis', 'CUATRO'),
(352, 204, 2480, '2014-07-13 00:00:00', 'Denis', 'CUATRO'),
(585, 204, 2481, '2014-07-13 00:00:00', 'Denis', 'CUATRO'),
(585, 21, 2482, '2014-07-13 00:00:00', 'Denis', 'CUATRO'),
(355, 21, 2483, '2014-07-13 00:00:00', 'Denis', 'CUATRO'),
(0, 0, 2484, '2014-07-13 00:00:00', 'Denis', 'CUATRO'),
(640, 140, 2485, '2014-07-13 00:00:00', 'Denis', 'CUATRO'),
(640, 100, 2486, '2014-07-13 00:00:00', 'Denis', 'CUATRO'),
(660, 80, 2487, '2014-07-13 00:00:00', 'Denis', 'CUATRO'),
(680, 60, 2488, '2014-07-13 00:00:00', 'Denis', 'CUATRO'),
(720, 60, 2489, '2014-07-13 00:00:00', 'Denis', 'CUATRO'),
(760, 100, 2490, '2014-07-13 00:00:00', 'Denis', 'CUATRO'),
(760, 140, 2491, '2014-07-13 00:00:00', 'Denis', 'CUATRO'),
(720, 180, 2492, '2014-07-13 00:00:00', 'Denis', 'CUATRO'),
(680, 180, 2493, '2014-07-13 00:00:00', 'Denis', 'CUATRO'),
(640, 140, 2494, '2014-07-13 00:00:00', 'Denis', 'CUATRO'),
(376, 292, 2505, '2014-07-13 00:00:00', 'Denis', 'Alejandra'),
(199, 165, 2506, '2014-07-13 00:00:00', 'Denis', 'Alejandra'),
(610, 233, 2507, '2014-07-13 00:00:00', 'Denis', 'Alejandra'),
(254, 327, 2508, '2014-07-13 00:00:00', 'Denis', 'Alejandra'),
(283, 218, 2509, '2014-07-13 00:00:00', 'Denis', 'Alejandra'),
(508, 430, 2510, '2014-07-13 00:00:00', 'Denis', 'Alejandra'),
(179, 143, 2511, '2014-07-13 00:00:00', 'Denis', 'UNO'),
(619, 246, 2512, '2014-07-13 00:00:00', 'Denis', 'UNO'),
(318, 402, 2513, '2014-07-13 00:00:00', 'Denis', 'UNO'),
(177, 143, 2514, '2014-07-13 00:00:00', 'Denis', 'UNO'),
(234, 160, 2531, '2014-07-13 00:00:00', 'Denis', 'TRES'),
(102, 285, 2532, '2014-07-13 00:00:00', 'Denis', 'TRES');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Graficos_temp`
--

CREATE TABLE IF NOT EXISTS `Graficos_temp` (
  `x` int(10) DEFAULT NULL,
  `y` int(10) DEFAULT NULL,
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `fecha` datetime DEFAULT NULL,
  `usuario` varchar(20) DEFAULT NULL,
  `nombre` varchar(30) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COMMENT='latin1_swedish_ci' AUTO_INCREMENT=2497 ;

--
-- Volcado de datos para la tabla `Graficos_temp`
--

INSERT INTO `Graficos_temp` (`x`, `y`, `id`, `fecha`, `usuario`, `nombre`) VALUES
(140, 22, 2474, '2014-07-13 00:00:00', 'Denis', 'CUATRO'),
(21, 203, 2475, '2014-07-13 00:00:00', 'Denis', 'CUATRO'),
(282, 203, 2476, '2014-07-13 00:00:00', 'Denis', 'CUATRO'),
(142, 23, 2477, '2014-07-13 00:00:00', 'Denis', 'CUATRO'),
(0, 0, 2478, '2014-07-13 00:00:00', 'Denis', 'CUATRO'),
(352, 21, 2479, '2014-07-13 00:00:00', 'Denis', 'CUATRO'),
(352, 204, 2480, '2014-07-13 00:00:00', 'Denis', 'CUATRO'),
(585, 204, 2481, '2014-07-13 00:00:00', 'Denis', 'CUATRO'),
(585, 21, 2482, '2014-07-13 00:00:00', 'Denis', 'CUATRO'),
(355, 21, 2483, '2014-07-13 00:00:00', 'Denis', 'CUATRO'),
(0, 0, 2484, '2014-07-13 00:00:00', 'Denis', 'CUATRO'),
(640, 140, 2485, '2014-07-13 00:00:00', 'Denis', 'CUATRO'),
(640, 100, 2486, '2014-07-13 00:00:00', 'Denis', 'CUATRO'),
(660, 80, 2487, '2014-07-13 00:00:00', 'Denis', 'CUATRO'),
(680, 60, 2488, '2014-07-13 00:00:00', 'Denis', 'CUATRO'),
(720, 60, 2489, '2014-07-13 00:00:00', 'Denis', 'CUATRO'),
(760, 100, 2490, '2014-07-13 00:00:00', 'Denis', 'CUATRO'),
(760, 140, 2491, '2014-07-13 00:00:00', 'Denis', 'CUATRO'),
(720, 180, 2492, '2014-07-13 00:00:00', 'Denis', 'CUATRO'),
(680, 180, 2493, '2014-07-13 00:00:00', 'Denis', 'CUATRO'),
(640, 140, 2494, '2014-07-13 00:00:00', 'Denis', 'CUATRO'),
(167, 310, 2495, NULL, NULL, 'CUATRO'),
(289, 318, 2496, NULL, NULL, 'CUATRO');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Proyecto`
--

CREATE TABLE IF NOT EXISTS `Proyecto` (
  `Proyecto_id` int(11) NOT NULL AUTO_INCREMENT,
  `Proyecto_nombre` text NOT NULL,
  `fecha_i` datetime NOT NULL,
  `fecha_f` datetime NOT NULL,
  `Public` int(1) NOT NULL DEFAULT '1',
  `Usuario` text NOT NULL,
  PRIMARY KEY (`Proyecto_id`),
  FULLTEXT KEY `Proyecto_nombre` (`Proyecto_nombre`),
  FULLTEXT KEY `Proyecto_nombre_2` (`Proyecto_nombre`),
  FULLTEXT KEY `Usuario` (`Usuario`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COMMENT='latin1_swedish_ci' AUTO_INCREMENT=56 ;

--
-- Volcado de datos para la tabla `Proyecto`
--

INSERT INTO `Proyecto` (`Proyecto_id`, `Proyecto_nombre`, `fecha_i`, `fecha_f`, `Public`, `Usuario`) VALUES
(46, 'Proyecto rectas', '2014-06-22 00:00:00', '2014-07-12 00:00:00', 1, 'Denis'),
(45, 'Proyecto tres', '2014-06-22 00:00:00', '2014-07-12 00:00:00', 1, 'Denis'),
(44, 'Proyecto dos', '2014-06-22 00:00:00', '2014-06-22 00:00:00', 1, 'Denis'),
(43, 'Proyecto uno', '2014-06-22 00:00:00', '2014-06-22 00:00:00', 1, 'Denis'),
(47, 'Proyecto cuatro', '2014-06-22 00:00:00', '2014-07-13 00:00:00', 1, 'Denis'),
(48, 'UNO', '2014-06-29 00:00:00', '2014-07-13 00:00:00', 1, 'Denis'),
(49, 'DOS', '2014-06-29 00:00:00', '2014-07-12 00:00:00', 1, 'Denis'),
(50, 'TRES', '2014-06-29 00:00:00', '2014-07-13 00:00:00', 1, 'Denis'),
(51, 'PROYECTO ONE', '2014-06-29 00:00:00', '2014-07-12 00:00:00', 1, 'Denis'),
(52, 'Alejandra', '2014-07-05 00:00:00', '2014-07-13 00:00:00', 1, 'Denis'),
(53, 'CUATRO', '2014-07-06 00:00:00', '2014-07-13 00:00:00', 1, 'Denis'),
(54, 'Proyecto triangulo', '2014-07-12 00:00:00', '2014-07-12 00:00:00', 1, 'Denis'),
(55, 'ESTRELLA', '2014-07-13 00:00:00', '2014-07-13 00:00:00', 1, 'Denis');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Proyecto_old`
--

CREATE TABLE IF NOT EXISTS `Proyecto_old` (
  `Proyecto_id` int(11) NOT NULL AUTO_INCREMENT,
  `Proyecto_nombre` text NOT NULL,
  `fecha_i` datetime NOT NULL,
  `fecha_f` datetime NOT NULL,
  `Public` int(1) NOT NULL DEFAULT '1',
  `Usuario` text NOT NULL,
  PRIMARY KEY (`Proyecto_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COMMENT='latin1_swedish_ci' AUTO_INCREMENT=35 ;

--
-- Volcado de datos para la tabla `Proyecto_old`
--

INSERT INTO `Proyecto_old` (`Proyecto_id`, `Proyecto_nombre`, `fecha_i`, `fecha_f`, `Public`, `Usuario`) VALUES
(32, 'UNO', '2014-02-16 00:00:00', '2014-02-16 00:00:00', 1, ''),
(33, 'UNO3', '2014-02-16 00:00:00', '2014-02-16 00:00:00', 1, 'Denis'),
(34, 'DOS', '2014-02-17 00:00:00', '2014-02-17 00:00:00', 1, 'Denis');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Usuario`
--

CREATE TABLE IF NOT EXISTS `Usuario` (
  `NOMBRE` varchar(10) NOT NULL,
  `CARGO` varchar(20) NOT NULL,
  `PASS` varchar(20) NOT NULL,
  PRIMARY KEY (`NOMBRE`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `Usuario`
--

INSERT INTO `Usuario` (`NOMBRE`, `CARGO`, `PASS`) VALUES
('Denis', 'Administrador', 'funckoffx'),
('manu', 'Limitado', 'manu08ar');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
